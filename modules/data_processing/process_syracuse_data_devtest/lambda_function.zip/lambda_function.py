# Process Syracuse scraped data
import json
import boto3
from datetime import datetime
import pandas as pd
from io import StringIO
import csv

rawzone_bucket = 'peeeq-datalake-raw-zone'
orgdomain_bucket = 'peeeq-datalake-organized-zone'
#Make sure you provide / in the end
prefix = 'syracuse/' 

clients3 = boto3.client('s3')

resources3 = boto3.resource('s3')
rawzone = resources3.Bucket(rawzone_bucket)
#orgdomainzone = resources3.Bucket(orgdomain_bucket)

columns_currently_used = ['event_url','ea_name','loc_name', 'loc_address', 'img_key', 'lat', 'lng', 'day_of_event', 'time_of_event', 'frequency', 'start_date', 'end_date', 'category', 'description', 'contact_phone', 'price']


def get_new_and_removed_rows_df(todays_df, yesterdays_df):
    print(todays_df.equals(yesterdays_df))
    #merged_df = todays_df.merge(yesterdays_df, on=columns_currently_used, how = 'outer' ,indicator=True)
    rows_added = todays_df.merge(yesterdays_df, on=columns_currently_used, how = 'outer' ,indicator=True).loc[lambda x : x['_merge']=='left_only']
    rows_removed = todays_df.merge(yesterdays_df, on=columns_currently_used, how = 'outer' ,indicator=True).loc[lambda x : x['_merge']=='right_only']
    return rows_added, rows_removed
    

def lambda_handler(event, context):
    # TODO implement
    ## 1. read in current data from organized domains - event_master, adhoc, and recurrent
    ## 2. read in new data recieved from all syracuse establishments
    ## 3. add neewly recieved data from each establishment to existing organized data
    
    # list of syracuse establishments
    syracuse_targets = [] # targets are establishments
    result = clients3.list_objects(Bucket=rawzone_bucket, Prefix=prefix, Delimiter='/')
    for o in result.get('CommonPrefixes'):
        #print(o.get('Prefix'))
        syracuse_targets.append(o.get('Prefix'))
    
    cum_rows_added_df = pd.DataFrame()
    cum_rows_removed_df = pd.DataFrame()
    
    for locs in syracuse_targets:
        # 1. calculate new updates recieved today - new events, updates to existing events
        print(locs)
        ## func that returns diff, on none, for locs
        dates_list = []
        for object_summary in rawzone.objects.filter(Prefix=locs):
            #print(datetime.strptime(object_summary.key.split('/')[-2], "%Y-%m-%d").date())
            dates_list.append(datetime.strptime(object_summary.key.split('/')[-2], "%Y-%m-%d").date())
            # syracuse_targets.append(o.get('Prefix'))
        dates_list = sorted(dates_list) # ascending sort
       # print(len(dates_list))  ## Add an exception to handle if scrapper didn't run
        if len(dates_list) > 1:
            todays_prefix = locs + str(dates_list[-1]) +'/df.csv'
            yesterdays_prefix = locs + str(dates_list[-2]) + '/df.csv'
            # today's
            todays_obj = clients3.get_object(Bucket= rawzone_bucket, Key= todays_prefix) 
            todays_df = pd.read_csv(todays_obj['Body'])
            # yesterday's
            yesterdays_obj = clients3.get_object(Bucket= rawzone_bucket, Key= yesterdays_prefix) 
            yesterdays_df = pd.read_csv(yesterdays_obj['Body'])
            # print(yesterdays_df.shape) 
            rows_added, rows_removed = get_new_and_removed_rows_df(todays_df, yesterdays_df)
            rows_added, rows_removed = rows_added[columns_currently_used], rows_removed[columns_currently_used]
        else:
            todays_prefix = locs + str(dates_list[-1]) + '/df.csv'
            #print(todays_prefix)
            todays_obj = clients3.get_object(Bucket= rawzone_bucket, Key= todays_prefix) 
            todays_df = pd.read_csv(todays_obj['Body'])
            rows_added = todays_df[columns_currently_used]
        #print('cum_rows_added_df:', cum_rows_added_df.shape)    
        cum_rows_added_df = pd.concat([cum_rows_added_df, rows_added], ignore_index = True)
        cum_rows_removed_df = pd.concat([cum_rows_removed_df, rows_removed], ignore_index = True)
    
    ## filling in end_date = start_date for adhoc events
    cum_rows_added_df.end_date.fillna(cum_rows_added_df.start_date, inplace=True) 
    ## One time event master seeding ## WRITE TO S3 HELPER CODE
    # bucket = 'peeeq-datalake-organized-zone' # 'eventactivityscrapperdata'
    # df = cum_rows_added_df
    # csv_buffer = StringIO()
    # df.to_csv(csv_buffer)
    # s3_resource = boto3.resource('s3')
    # # today = date.today()
    # object_key = 'event_master.csv'
    # s3_resource.Object(bucket, object_key).put(Body=csv_buffer.getvalue())
    # print("object written!")

    # 2. append new events to respective datasets in organized domains
    ## read in current event master dataset
    S3_BUCKET_NAME = orgdomain_bucket
    S3_BUCKET_PREFIX = 'event_master.csv'
    obj = clients3.get_object(Bucket= S3_BUCKET_NAME, Key= S3_BUCKET_PREFIX) 
    event_master_df = pd.read_csv(obj['Body'])

    ## remove data i.e. cum_rows_removed_df. Removal should be done before adding new data so that 
    ## any updates to the events are captured. The changes are tracked on columns_currently_used
    # print(cum_rows_added_df['event_url'].isin(cum_rows_removed_df['event_url']).sum())
    # print('event_master_df',event_master_df.shape)
    event_master_df = event_master_df.drop(event_master_df[ event_master_df['event_url'].isin(cum_rows_removed_df['event_url']) ].index)
    # print('event_master_df', event_master_df.shape)
    
    ## Add data i.e. cum_rows_added_df
    event_master_df = pd.concat([event_master_df, cum_rows_added_df], ignore_index = True)
    # remove duplicate
    event_master_df = event_master_df.drop_duplicates(subset=['event_url'], ignore_index= True)
    
    # 3. update respective datasets/rows in organized domains
    ## write back event master
    #bucket = 'peeeq-datalake-organized-zone' # 'eventactivityscrapperdata'
    #df = event_master_df
    csv_buffer = StringIO()
    event_master_df.to_csv(csv_buffer)
    #s3_resource = boto3.resource('s3')
    # today = date.today()
    object_key = 'event_master_devtest.csv'
    resources3.Object(orgdomain_bucket, object_key).put(Body=csv_buffer.getvalue())
    print("object written!")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }